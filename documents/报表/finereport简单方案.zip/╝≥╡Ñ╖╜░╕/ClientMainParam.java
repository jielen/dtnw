package com.fr.io;

import com.fr.page.ReportPage;
import com.fr.page.pageset.ArrayPageSet;
import com.fr.page.pageset.PageSet;
import com.fr.print.PrintUtils;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;

import java.awt.print.PrinterException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

public class ClientMainParam {

    public static void main(String[] args) throws UnsupportedEncodingException, IllegalStateException, IOException {
        HttpClient httpclient = new DefaultHttpClient();
        HttpPost httppost = new HttpPost("http://localhost:8075/WebReport/servletWork?");

        List<NameValuePair> formparams = new ArrayList<NameValuePair>();
        formparams.add(new BasicNameValuePair("WorkBookName", "test22.cpt"));
        formparams.add(new BasicNameValuePair("__rawDataString__", "isjavaprint=true"));
        UrlEncodedFormEntity entity = new UrlEncodedFormEntity(formparams, HTTP.UTF_8);
        httppost.setEntity(entity);
        HttpResponse response = httpclient.execute(httppost);
        if (response.getStatusLine().getStatusCode() == 200){

            Header[] header = response.getAllHeaders();
            for (Header header2 : header) {
                System.out.println(header2);
            }

            HttpEntity resEntity = response.getEntity();
            String jsonResult = EntityUtils.toString(resEntity);
            System.out.println(jsonResult);
            ReportPage[] ReportPagearr = new ReportPage[1];

            ReportPagearr[0]=ReportPage.deXmlizable(jsonResult);
            PageSet pageSet2=new  ArrayPageSet(ReportPagearr,true);
            try {
                PrintUtils.print(pageSet2,true);
            } catch (PrinterException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }


        }


    }
}  