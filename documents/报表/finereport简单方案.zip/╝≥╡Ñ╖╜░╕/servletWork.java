package com.fr.io;
import com.fr.base.FRContext;
import com.fr.base.ModuleContext;
import com.fr.dav.LocalEnv;
import com.fr.main.impl.WorkBook;
import com.fr.page.ReportPage;
import com.fr.page.pageset.PageSet;
import com.fr.report.core.ReportUtils;
import com.fr.report.module.EngineModule;
import com.fr.web.utils.WebUtils;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
public class servletWork extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private static final String CONTENT_TYPE = "text/html; charset=GBK";
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
        doGet(request, response);
    }

    //Process the HTTP Get request
    public void doGet(HttpServletRequest req, HttpServletResponse res) throws  ServletException, IOException
    {
        String envPath = "D:\\FineReport_7.04\\WebReport\\WEB-INF";
        FRContext.setCurrentEnv(new LocalEnv(envPath));
        FRContext.setCurrentEnv(new LocalEnv(envPath));
        ModuleContext.startModule(EngineModule.class.getName());
        String workname = WebUtils.getHTTPRequestParameter(req, "WorkBookName");
        String rawDataString = WebUtils.getHTTPRequestParameter(req, "__rawDataString__");
        HashMap<String, String> paraMap = analysis(rawDataString);
        try {
            // ��ȡģ��
            WorkBook workbook = (WorkBook) TemplateWorkBookIO
                    .readTemplateWorkBook(FRContext.getCurrentEnv(),
                            workname);
            // ���WorkBook�е�WorkSheet�������޸�A1��Ԫ���ǰ��ɫΪ��ɫ
            // java�е��ñ�����ӡ����

            PageSet pageSet = workbook.execute(paraMap).generateReportPageSet(ReportUtils.getPaperSettingListFromWorkBook(workbook)).traverse4Export();

            FRContext.getLogger().info("pageSetsize"+String.valueOf(pageSet.size()));
            for (int j = 0;j<pageSet.size();j++)
            {
                ServletOutputStream out = res.getOutputStream();
                ReportPage.xmlizable(pageSet.getPage(j), out, true);
                out.println();
            }
            res.setContentType(CONTENT_TYPE);
        }
        catch (Exception e) {
            e.getStackTrace();
        }
    }

    public HashMap<String, String> analysis( String normal) {
        String paramaters[] = normal.split("&");
        java.util.Map<String, String> paraMap = new java.util.HashMap<String, String>();
        for (int i = 0; i < paramaters.length; i++) {
            String values[] = paramaters[i].split("=");

            paraMap.put(values[0], values[1]);
        }
        return (HashMap<String, String>) paraMap;
    }
}
          
          
 

